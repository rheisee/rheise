//= require manual/_general
//= require manual/_guided-tour-demo
//= require manual/_forms
